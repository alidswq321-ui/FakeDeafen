(vendetta => {
    const React = vendetta.metro.common.React;
    const RN = vendetta.metro.common.ReactNative;
    const storage = vendetta.plugin.storage;

    if (typeof storage.fakeDeafenEnabled !== "boolean") {
        storage.fakeDeafenEnabled = false;
    }

    function FakeDeafenSettings() {
        const [enabled, setEnabled] = React.useState(!!storage.fakeDeafenEnabled);

        const toggle = (value) => {
            setEnabled(value);
            storage.fakeDeafenEnabled = value;
        };

        return React.createElement(
            RN.View,
            { style: { padding: 16, gap: 12 } },
            React.createElement(
                RN.Text,
                { style: { fontSize: 18, fontWeight: "700", color: "#fff" } },
                "FakeDeafen"
            ),
            React.createElement(
                RN.Text,
                { style: { color: "#b9bbbe", lineHeight: 20 } },
                "تجربة محلية فقط: هذا المفتاح يحفظ اختيارك داخل الإضافة. لا يغيّر حالة Deafen في Discord، ولا يجعل الآخرين يرونك مكتومًا."
            ),
            React.createElement(
                RN.View,
                { style: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", paddingVertical: 10 } },
                React.createElement(
                    RN.Text,
                    { style: { color: "#fff", fontSize: 16 } },
                    enabled ? "FakeDeafen: ON" : "FakeDeafen: OFF"
                ),
                React.createElement(RN.Switch, {
                    value: enabled,
                    onValueChange: toggle
                })
            ),
            React.createElement(
                RN.Text,
                { style: { color: "#f0b232", fontSize: 12, lineHeight: 18 } },
                "مهم: لا تستخدم هذا كدليل على أن حالة Deafen تغيّرت. الزر تجريبي في صفحة إعدادات الإضافة فقط."
            )
        );
    }

    return {
        settings: React.createElement(FakeDeafenSettings),
        onUnload: () => {}
    };
})
