# FakeDeafen (experimental)

This is a minimal Vendetta-format plugin package.

## What it does
- Adds a FakeDeafen settings page with an ON/OFF switch.
- Saves the switch state in plugin storage.

## What it does NOT do
- It does not set Discord's server-side Deafen state.
- It does not show a Deafen icon to other users.
- It does not add a button to the voice-call toolbar.
- It does not modify or mute voice audio.

The plugin is intentionally limited to a safe local UI toggle because a true
server-visible Deafen state while still receiving voice audio cannot be
achieved by merely changing a local icon.
